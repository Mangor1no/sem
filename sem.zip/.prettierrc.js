module.exports = {
  printWidth: 100,
  bracketSpacing: true,
  jsxBracketSameLine: false,
  singleQuote: true,
  trailingComma: 'es5',
  semi: true,
  tabWidth: 2,
  endOfLine: 'lf',
};
